package com.newmadurga.billing;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT=701, REQ_CAMERA=702, REQ_FILE=703;
    private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView web;
    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private Thread connectThread;
    private final Object lock=new Object();
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest cameraRequest;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("printer",MODE_PRIVATE);
        adapter=BluetoothAdapter.getDefaultAdapter();
        web=new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent pick=new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                try { startActivityForResult(Intent.createChooser(pick,"ছবি নির্বাচন করুন"),REQ_FILE); }
                catch(Exception e) { fileCallback=null; callback.onReceiveValue(null); toast("Gallery খোলা যাচ্ছে না"); }
                return true;
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                boolean wantsCamera=false;
                for(String r:request.getResources()) if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCamera=true;
                if(!wantsCamera){ request.deny(); return; }
                runOnUiThread(() -> {
                    if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) {
                        cameraRequest=request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);
                    } else request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                });
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new PrinterBridge(),"AndroidPrinter");
        web.addJavascriptInterface(new NativeFilesBridge(),"AndroidFiles");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        requestBluetoothPermissionAndReconnect();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_FILE && fileCallback!=null) {
            Uri[] result=null;
            if(resultCode==RESULT_OK && data!=null) {
                Uri u=data.getData();
                if(u!=null) result=new Uri[]{u};
            }
            fileCallback.onReceiveValue(result);
            fileCallback=null;
        }
    }

    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==REQ_BT) {
            if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) autoReconnect();
            else toast("Bluetooth অনুমতি দিন");
        } else if(code==REQ_CAMERA) {
            if(cameraRequest!=null) {
                if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED)
                    cameraRequest.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                else cameraRequest.deny();
                cameraRequest=null;
            }
        }
    }

    private void requestBluetoothPermissionAndReconnect() {
        if(adapter==null){toast("এই ফোনে Bluetooth নেই");return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
        else autoReconnect();
    }
    private void autoReconnect() {
        try {
            if(adapter==null || !adapter.isEnabled()){toast("Bluetooth চালু করুন");return;}
            String mac=prefs.getString("mac","");
            if(!mac.isEmpty()) connect(mac,false);
        } catch(SecurityException e){toast("Bluetooth অনুমতি দিন");}
    }
    private void connect(String mac,boolean save) {
        if(adapter==null)return;
        if(connectThread!=null)connectThread.interrupt();
        connectThread=new Thread(() -> {
            BluetoothSocket s=null;
            try {
                BluetoothDevice d=adapter.getRemoteDevice(mac);
                try { s=d.createRfcommSocketToServiceRecord(SPP); s.connect(); }
                catch(Exception secureError) {
                    try { if(s!=null)s.close(); } catch(Exception ignored){}
                    s=d.createInsecureRfcommSocketToServiceRecord(SPP);
                    s.connect();
                }
                synchronized(lock){if(socket!=null)try{socket.close();}catch(Exception ignored){} socket=s;}
                if(save)prefs.edit().putString("mac",mac).apply();
                toast("Bluetooth Printer Connected: "+d.getName());
            } catch(Exception e) {
                if(s!=null)try{s.close();}catch(Exception ignored){}
                toast("Bluetooth কানেক্ট হয়নি। প্রিন্টার Pair করে আবার Connect করুন।");
            }
        });
        connectThread.start();
    }
    private void choosePrinter() {
        if(adapter==null){toast("এই ফোনে Bluetooth নেই");return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionAndReconnect(); return;
        }
        try {
            Set<BluetoothDevice> paired=adapter.getBondedDevices();
            ArrayList<BluetoothDevice> list=new ArrayList<>();
            for(BluetoothDevice d:paired)list.add(d);
            if(list.isEmpty()){toast("আগে ফোনের Bluetooth Settings থেকে ATPOS M80 Pair করুন");return;}
            String[] names=new String[list.size()];
            for(int i=0;i<list.size();i++)names[i]=(list.get(i).getName()==null?"Bluetooth Printer":list.get(i).getName())+"\n"+list.get(i).getAddress();
            new AlertDialog.Builder(this).setTitle("ATPOS M80 নির্বাচন করুন")
                .setItems(names,(dialog,which)->connect(list.get(which).getAddress(),true))
                .setNegativeButton("বাতিল",null).show();
        } catch(SecurityException e){toast("Bluetooth অনুমতি দিন");}
    }

    private class PrinterBridge {
        @JavascriptInterface public void connectPrinter(){runOnUiThread(()->choosePrinter());}
        @JavascriptInterface public boolean isConnected(){synchronized(lock){return socket!=null&&socket.isConnected();}}
        @JavascriptInterface public void printImage(String dataUrl) {
            new Thread(() -> {
                Bitmap source=null,bmp=null;
                try {
                    int comma=dataUrl.indexOf(',');
                    byte[] raw=Base64.decode(comma>=0?dataUrl.substring(comma+1):dataUrl,Base64.DEFAULT);
                    source=BitmapFactory.decodeByteArray(raw,0,raw.length);
                    if(source==null)throw new Exception("Invalid image");
                    int width=576,height=Math.max(1,(int)Math.round(source.getHeight()*(width/(double)source.getWidth())));
                    bmp=Bitmap.createScaledBitmap(source,width,height,true);
                    int row=(width+7)/8; byte[] raster=new byte[row*height];
                    for(int y=0;y<height;y++)for(int x=0;x<width;x++){
                        int c=bmp.getPixel(x,y);
                        int gray=(android.graphics.Color.red(c)*299+android.graphics.Color.green(c)*587+android.graphics.Color.blue(c)*114)/1000;
                        if(gray<178)raster[y*row+x/8]|=(byte)(0x80>>(x%8));
                    }
                    OutputStream out;
                    synchronized(lock){if(socket==null||!socket.isConnected())throw new Exception("Printer disconnected");out=socket.getOutputStream();}
                    out.write(new byte[]{0x1b,0x40});
                    out.write(new byte[]{0x1d,0x76,0x30,0x00,(byte)(row&255),(byte)((row>>8)&255),(byte)(height&255),(byte)((height>>8)&255)});
                    out.write(raster);out.write(new byte[]{0x1b,0x64,0x04});out.write(new byte[]{0x1d,0x56,0x00});out.flush();
                    toast("ATPOS M80-এ বিল প্রিন্ট পাঠানো হয়েছে");
                } catch(Exception e){toast("প্রিন্ট হয়নি। Printer Connect করুন।");}
                finally{if(source!=null)source.recycle();if(bmp!=null&&bmp!=source)bmp.recycle();}
            }).start();
        }
    }

    private class NativeFilesBridge {
        @JavascriptInterface public void shareFile(String dataUrl,String mime,String fileName) {
            new Thread(() -> {
                try {
                    int comma=dataUrl.indexOf(',');
                    byte[] bytes=Base64.decode(comma>=0?dataUrl.substring(comma+1):dataUrl,Base64.DEFAULT);
                    String safeName=fileName.replaceAll("[^A-Za-z0-9._-]","_");
                    ContentValues values=new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME,safeName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE,mime);
                    if(Build.VERSION.SDK_INT>=29)values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/New Ma Durga Bills");
                    Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                    if(uri==null)throw new IOException("ফাইল সংরক্ষণ করা যায়নি");
                    OutputStream out=getContentResolver().openOutputStream(uri);
                    if(out==null)throw new IOException("ফাইল লেখা যায়নি");
                    out.write(bytes);out.flush();out.close();
                    runOnUiThread(() -> {
                        Intent send=new Intent(Intent.ACTION_SEND);
                        send.setType(mime);send.putExtra(Intent.EXTRA_STREAM,uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send,"বিল শেয়ার করুন"));
                    });
                } catch(Exception e){toast("বিল তৈরি হয়েছে, কিন্তু Share খোলা যায়নি। Downloads ফোল্ডার দেখুন।");}
            }).start();
        }
    }

    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
