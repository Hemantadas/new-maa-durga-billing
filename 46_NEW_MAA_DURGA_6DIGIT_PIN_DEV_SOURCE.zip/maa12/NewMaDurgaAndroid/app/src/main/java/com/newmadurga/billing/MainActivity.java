package com.newmadurga.billing;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import android.widget.Toast;
import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT=701, REQ_CAMERA=702, REQ_FILE=703;
    private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView web;
    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private Thread connectThread;
    private final Object lock=new Object();
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest cameraRequest;
    private boolean pendingPrinterPicker=false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("printer",MODE_PRIVATE);
        adapter=BluetoothAdapter.getDefaultAdapter();
        web=new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent pick=new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                try { startActivityForResult(Intent.createChooser(pick,"ছবি নির্বাচন করুন"),REQ_FILE); }
                catch(Exception e) { fileCallback=null; callback.onReceiveValue(null); toast("Gallery খোলা যাচ্ছে না"); }
                return true;
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                boolean wantsCamera=false;
                for(String r:request.getResources()) if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCamera=true;
                if(!wantsCamera){ request.deny(); return; }
                runOnUiThread(() -> {
                    if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) {
                        cameraRequest=request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);
                    } else request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                });
            }
        });
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new PrinterBridge(),"AndroidPrinter");
        web.addJavascriptInterface(new NativeFilesBridge(),"AndroidFiles");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        requestBluetoothPermissionAndReconnect();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_FILE && fileCallback!=null) {
            Uri[] result=null;
            if(resultCode==RESULT_OK && data!=null) {
                Uri u=data.getData();
                if(u!=null) result=new Uri[]{u};
            }
            fileCallback.onReceiveValue(result);
            fileCallback=null;
        }
    }

    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==REQ_BT) {
            if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) {
                if(pendingPrinterPicker) { pendingPrinterPicker=false; choosePrinter(); }
                else autoReconnect();
            } else { pendingPrinterPicker=false; toast("Bluetooth অনুমতি দিন"); }
        } else if(code==REQ_CAMERA) {
            if(cameraRequest!=null) {
                if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED)
                    cameraRequest.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                else cameraRequest.deny();
                cameraRequest=null;
            }
        }
    }

    private void requestBluetoothPermissionAndReconnect() {
        if(adapter==null){toast("এই ফোনে Bluetooth নেই");return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
        else autoReconnect();
    }
    private void autoReconnect() {
        try {
            if(adapter==null || !adapter.isEnabled()){toast("Bluetooth চালু করুন");return;}
            String mac=prefs.getString("mac","");
            if(!mac.isEmpty()) connect(mac,false);
        } catch(SecurityException e){toast("Bluetooth অনুমতি দিন");}
    }
    private void connect(String mac,boolean save) {
        if(adapter==null)return;
        if(connectThread!=null)connectThread.interrupt();
        connectThread=new Thread(() -> {
            BluetoothSocket s=null;
            try {
                BluetoothDevice d=adapter.getRemoteDevice(mac);
                try { s=d.createRfcommSocketToServiceRecord(SPP); s.connect(); }
                catch(Exception secureError) {
                    try { if(s!=null)s.close(); } catch(Exception ignored){}
                    s=d.createInsecureRfcommSocketToServiceRecord(SPP);
                    s.connect();
                }
                synchronized(lock){if(socket!=null)try{socket.close();}catch(Exception ignored){} socket=s;}
                if(save)prefs.edit().putString("mac",mac).apply();
                toast("Bluetooth Printer Connected: "+d.getName());
            } catch(Exception e) {
                if(s!=null)try{s.close();}catch(Exception ignored){}
                toast("Bluetooth কানেক্ট হয়নি। প্রিন্টার Pair করে আবার Connect করুন।");
            }
        });
        connectThread.start();
    }
    private void choosePrinter() {
        if(adapter==null){toast("এই ফোনে Bluetooth নেই");return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) {
            pendingPrinterPicker=true;
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
            return;
        }
        try {
            Set<BluetoothDevice> paired=adapter.getBondedDevices();
            ArrayList<BluetoothDevice> list=new ArrayList<>();
            for(BluetoothDevice d:paired)list.add(d);
            if(list.isEmpty()){toast("আগে ফোনের Bluetooth Settings থেকে ATPOS M80 Pair করুন");return;}
            String[] names=new String[list.size()];
            for(int i=0;i<list.size();i++)names[i]=(list.get(i).getName()==null?"Bluetooth Printer":list.get(i).getName())+"\n"+list.get(i).getAddress();
            new AlertDialog.Builder(this).setTitle("ATPOS M80 নির্বাচন করুন")
                .setItems(names,(dialog,which)->connect(list.get(which).getAddress(),true))
                .setNegativeButton("বাতিল",null).show();
        } catch(SecurityException e){toast("Bluetooth অনুমতি দিন");}
    }

    private class PrinterBridge {
        @JavascriptInterface public void connectPrinter(){runOnUiThread(()->choosePrinter());}
        @JavascriptInterface public boolean isConnected(){synchronized(lock){return socket!=null&&socket.isConnected();}}
        @JavascriptInterface public void printImage(String dataUrl) {
            new Thread(() -> {
                Bitmap source=null,bmp=null;
                try {
                    int comma=dataUrl.indexOf(',');
                    byte[] raw=Base64.decode(comma>=0?dataUrl.substring(comma+1):dataUrl,Base64.DEFAULT);
                    source=BitmapFactory.decodeByteArray(raw,0,raw.length);
                    if(source==null)throw new Exception("Invalid image");
                    int width=576,height=Math.max(1,(int)Math.round(source.getHeight()*(width/(double)source.getWidth())));
                    bmp=Bitmap.createScaledBitmap(source,width,height,true);
                    int row=(width+7)/8; byte[] raster=new byte[row*height];
                    for(int y=0;y<height;y++)for(int x=0;x<width;x++){
                        int c=bmp.getPixel(x,y);
                        int gray=(android.graphics.Color.red(c)*299+android.graphics.Color.green(c)*587+android.graphics.Color.blue(c)*114)/1000;
                        // Preserve anti-aliased Bengali matra and thin strokes when converting to 1-bit thermal dots.
                        if(gray<225)raster[y*row+x/8]|=(byte)(0x80>>(x%8));
                    }
                    OutputStream out;
                    synchronized(lock){if(socket==null||!socket.isConnected())throw new Exception("Printer disconnected");out=socket.getOutputStream();}
                    out.write(new byte[]{0x1b,0x40});
                    out.write(new byte[]{0x1d,0x76,0x30,0x00,(byte)(row&255),(byte)((row>>8)&255),(byte)(height&255),(byte)((height>>8)&255)});
                    out.write(raster);out.write(new byte[]{0x1b,0x64,0x04});out.write(new byte[]{0x1d,0x56,0x00});out.flush();
                    toast("ATPOS M80-এ বিল প্রিন্ট পাঠানো হয়েছে");
                } catch(Exception e){toast("প্রিন্ট হয়নি। Printer Connect করুন।");}
                finally{if(source!=null)source.recycle();if(bmp!=null&&bmp!=source)bmp.recycle();}
            }).start();
        }
    }

    private class NativeFilesBridge {
        @JavascriptInterface public void shareFile(String dataUrl,String mime,String fileName) {
            new Thread(() -> {
                File shareFile=null;
                try {
                    int comma=dataUrl.indexOf(',');
                    byte[] bytes=Base64.decode(comma>=0?dataUrl.substring(comma+1):dataUrl,Base64.DEFAULT);
                    String safeName=fileName.replaceAll("[^A-Za-z0-9._-]","_");
                    if(bytes.length==0)throw new IOException("খালি ফাইল");

                    // Always create a FileProvider URI for the Android share sheet.
                    File dir=new File(getCacheDir(),"shared_bills");
                    if(!dir.exists()&&!dir.mkdirs())throw new IOException("Share folder তৈরি হয়নি");
                    shareFile=new File(dir,System.currentTimeMillis()+"_"+safeName);
                    try(FileOutputStream out=new FileOutputStream(shareFile)){out.write(bytes);out.flush();}
                    Uri shareUri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",shareFile);

                    // Keep a downloadable copy as well. Android 10+ uses MediaStore Downloads;
                    // older Android versions use the app's external Downloads directory.
                    try {
                        if(Build.VERSION.SDK_INT>=29) {
                            ContentValues values=new ContentValues();
                            values.put(MediaStore.MediaColumns.DISPLAY_NAME,safeName);
                            values.put(MediaStore.MediaColumns.MIME_TYPE,mime);
                            values.put(MediaStore.MediaColumns.RELATIVE_PATH,"Download/New Ma Durga Bills");
                            Uri downloadUri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                            if(downloadUri!=null) {
                                try(OutputStream out=getContentResolver().openOutputStream(downloadUri)){if(out!=null)out.write(bytes);}
                            }
                        } else {
                            File downloads=getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS);
                            if(downloads!=null){File saved=new File(downloads,safeName);try(FileOutputStream out=new FileOutputStream(saved)){out.write(bytes);}}
                        }
                    } catch(Exception saveError) { /* Sharing can still proceed if saving a copy fails. */ }

                    final Uri finalUri=shareUri;
                    runOnUiThread(() -> {
                        try {
                            Intent send=new Intent(Intent.ACTION_SEND);
                            send.setType(mime);
                            send.putExtra(Intent.EXTRA_STREAM,finalUri);
                            send.putExtra(Intent.EXTRA_SUBJECT,"New Maa Durga Enterprise Bill");
                            send.putExtra(Intent.EXTRA_TEXT,"নিউ মা দূর্গা এন্টারপ্রাইজের বিল");
                            send.setClipData(ClipData.newUri(getContentResolver(),"Bill",finalUri));
                            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            // Explicitly grant the file URI to WhatsApp before launching its share target.
                            // If WhatsApp is absent or rejects this MIME type, always open Android's chooser.
                            boolean launched=false;
                            String[] targets={"com.whatsapp","com.whatsapp.w4b"};
                            for(String target:targets) {
                                try {
                                    grantUriPermission(target,finalUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    Intent direct=new Intent(Intent.ACTION_SEND);
                                    direct.setType(mime);
                                    direct.putExtra(Intent.EXTRA_STREAM,finalUri);
                                    direct.putExtra(Intent.EXTRA_SUBJECT,"New Maa Durga Enterprise Bill");
                                    direct.putExtra(Intent.EXTRA_TEXT,"নিউ মা দূর্গা এন্টারপ্রাইজের বিল");
                                    direct.setClipData(ClipData.newUri(getContentResolver(),"Bill",finalUri));
                                    direct.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                    direct.setPackage(target);
                                    startActivity(direct);
                                    launched=true;
                                    break;
                                } catch(Exception targetError) { /* Try the next target, then the system chooser. */ }
                            }
                            if(!launched) startActivity(Intent.createChooser(send,"WhatsApp / অন্য অ্যাপে বিল পাঠান"));
                        } catch(Exception e) { toast("Share খোলা যায়নি। আবার চেষ্টা করুন।"); }
                    });
                } catch(Exception e){toast("বিল শেয়ার তৈরি হয়নি। আবার চেষ্টা করুন।");}
            }).start();
        }
    }

    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
