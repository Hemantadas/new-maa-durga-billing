নিউ মা দূর্গা এন্টারপ্রাইজ — Android Bluetooth Printer App Source

লক্ষ্য ডিভাইস: Vivo X100 / OriginOS 6
প্রিন্টার: ATPOS M80, 79mm roll (80mm class), Bluetooth Classic SPP

এই ZIP হলো Android Studio source project; এটি APK ফাইল নয়। এই পরিবেশে Android SDK/Gradle build tools নেই, তাই APK কম্পাইল বা Vivo X100-এ পরীক্ষা করা সম্ভব হয়নি।

যা অন্তর্ভুক্ত:
- আগের billing web app WebView-এর মধ্যে চালানো
- প্রথমবার Android-এর bonded Bluetooth device list থেকে printer নির্বাচন
- নির্বাচিত printer-এর MAC address সংরক্ষণ এবং পরেরবার app start-এ reconnect চেষ্টা
- 80mm (576-dot) raster receipt সরাসরি Bluetooth SPP-তে পাঠানো
- Bengali text, logo ও QR সহ receipt image raster print path

Build:
1. Android Studio-তে এই project folder খুলুন
2. Android SDK Platform 35 এবং Android Gradle Plugin 8.6.1 সমর্থিত Gradle install/sync করুন
3. Build > Build APK(s)
4. app/build/outputs/apk/debug/app-debug.apk তৈরি হলে Vivo X100-এ install করুন
5. প্রথমবার ফোনের Bluetooth Settings-এ ATPOS M80 Pair করুন, তারপর অ্যাপের Print Setting > Bluetooth Connect চাপুন
6. Bluetooth permission Allow করুন এবং ATPOS M80 নির্বাচন করুন। পরেরবার অ্যাপ খোলার সময় আগের ডিভাইসে reconnect চেষ্টা করবে।

সীমাবদ্ধতা/পরীক্ষা:
- Auto-connect কেবল আগে Pair করা এবং Android permission অনুমোদিত ডিভাইসে চেষ্টা করা হয়। OS Bluetooth বন্ধ থাকলে বা প্রিন্টার বন্ধ/রেঞ্জের বাইরে থাকলে manual connect লাগবে।
- Printer firmware-এর ESC/POS raster command compatibility বাস্তব প্রিন্টারে যাচাই করা হয়নি।
- Bluetooth classic SPP UUID ব্যবহার করা হয়েছে; যদি আপনার M80 BLE-only mode-এ থাকে, আলাদা BLE implementation লাগবে।
- App-এর সব business flow অপরিবর্তিত রাখার চেষ্টা করা হয়েছে; বাস্তব ডিভাইসে end-to-end QA বাকি।


নতুন সংশোধন (Fixed ZIP):
1. Android WebView-এর Gallery/File chooser যুক্ত করা হয়েছে।
2. WebView Camera permission এবং Android CAMERA runtime permission যুক্ত করা হয়েছে।
3. Bluetooth-এ secure RFCOMM ব্যর্থ হলে insecure RFCOMM দিয়ে দ্বিতীয়বার চেষ্টা করা হয়।
4. Android অ্যাপে PDF/JPG তৈরি হলে Android Share chooser দিয়ে শেয়ার করার ব্যবস্থা যুক্ত করা হয়েছে; কপি Downloads/New Ma Durga Bills-এও সংরক্ষিত হয়।
5. Barcode স্ক্যানার ক্যামেরা খোলার অনুমতি পাবে। তবে ফোনের Android System WebView-তে BarcodeDetector না থাকলে ক্যামেরা খুললেও অটো বারকোড পড়বে না; সে ক্ষেত্রে Barcode নম্বর হাতে লিখতে হবে।

গুরুত্বপূর্ণ:
- এটি সংশোধিত Android Studio/Android IDE source project ZIP; APK নয়।
- এই ZIP-এ Gradle wrapper ফাইল নেই। Android IDE-তে প্রজেক্ট খুলে IDE-র Gradle ব্যবহার করে build করতে হবে।
- বাস্তব ফোনে Gallery, Bluetooth printer, PDF/JPG share এবং camera পরীক্ষা করা প্রয়োজন। Bluetooth pairing আগে ফোনের Settings থেকে করুন।

6. Quick Bill হোমস্ক্রিনের নিচের Clear Bill, Save Bill এবং Print তিনটি বোতাম সরানো হয়েছে; অন্য বিলিং ফিচার/ডিজাইন অক্ষত রাখা হয়েছে।

7. Quick Bill keypad-এর Save ও Enter বোতামের কাজ অদলবদল করা হয়েছে (লেবেল একই রাখা হয়েছে), ব্যবহারকারীর নিশ্চিতকরণ অনুযায়ী।


সর্বশেষ সংশোধন (৯ নভেম্বর ২০২৬):
- Quick Bill স্ক্রিনে Save বোতাম এখন Enter-এর মতো আইটেম যোগ করবে।
- Enter বোতাম এখন Save Bill ফর্ম খুলবে।
- Quick Bill স্ক্রিনে নিচের Clear Bill, Save Bill ও Print বোতাম রাখা হয়নি।


নতুন বিল ডিজাইন (10-11-2026): ব্যবহারকারীর Asli Bill রেফারেন্স অনুযায়ী সাদা-কালো রসিদ, উপরে কেন্দ্রের লোগো আপলোড, দোকানের তথ্য, Invoice/তারিখ, dashed separator, আইটেম টেবিলে HSN, Grand Total, Payment Mode, UPI QR এবং Powered By footer। বিলের টেবিলের বাইরে অতিরিক্ত ডিজাইন/রঙিন বর্ডার নেই।

নতুন প্রিন্ট লেআউট সংশোধন (১৭ নভেম্বর ২০২৬):
- লম্বা বাংলা/ইংরেজি পণ্যের নাম গ্রাফিম/অক্ষরভিত্তিক লাইনে ভাঙে, তাই HSN কলামের উপর উঠে যাওয়ার কথা নয়।
- আইটেমের নাম ও HSN-এর জন্য আলাদা প্রস্থ রাখা হয়েছে; QTY, RATE এবং AMOUNT নিজ নিজ কলামে থাকবে।
- প্রতিটি আইটেমের নিচে স্পষ্ট কালো বিভাজক দাগ।
- মোট মাল / TOTAL QTY এবং তার সংখ্যা একই লাইনে, তার উপরে মোটা কালো দাগ।
- GRAND TOTAL কালো ব্যাকগ্রাউন্ডে সাদা অক্ষরে।
- Canvas/Bluetooth এবং HTML print—দুই প্রিন্ট পথেই এই বিন্যাস রাখা হয়েছে।
- JavaScript syntax ও ZIP integrity পরীক্ষা করা হয়েছে; ATPOS M80-এ সরাসরি hardware print test করা হয়নি।
