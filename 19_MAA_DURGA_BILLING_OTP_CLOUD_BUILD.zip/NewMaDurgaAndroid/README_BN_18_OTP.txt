নিউ মা দূর্গা বিলিং — ১৮ নম্বর সোর্স ZIP

এই সংস্করণে লগইন পদ্ধতি: Firebase Phone SMS OTP। সাধারণ লগইনে PIN লাগবে না।

মূল বিষয়
1. দোকানের নিবন্ধিত মোবাইল নম্বরে SMS OTP পাঠিয়ে লগইন।
2. OTP যাচাই হলে Firebase Phone Authentication session তৈরি/পুনরুদ্ধার হবে।
3. অ্যাপ আবার চালু হলে Firebase-এর আগের লগইন session restore হওয়ার জন্য AuthStateListener যোগ করা হয়েছে।
4. একই Firebase phone account/UID দিয়ে অন্য ডিভাইসে লগইন করলে সেই account-এর Firestore cloud snapshot পড়ার ব্যবস্থা আছে।
5. বিল, পণ্য, কাস্টমার ও সেটিংস LocalStorage-এ থাকে এবং লগইন অবস্থায় Cloud Sync হয়।
6. Logout করলে Firestore-এর cloud data delete করা হয় না।
7. অ্যাপের বিল/রসিদ ডিজাইন এবং HSN কলাম এই আপডেটে ইচ্ছাকৃতভাবে পরিবর্তন করা হয়নি।

Firebase Console-এ একবারের সেটআপ
- Authentication > Sign-in method > Phone provider Enabled থাকতে হবে।
- Firestore Database তৈরি থাকতে হবে।
- Firestore Rules-এ এই ZIP-এর firestore/firestore.rules ফাইলের নিয়ম প্রকাশ (Publish) করতে হবে। বর্তমানে Console-এ যদি সব read/write false থাকে, তাহলে Cloud Sync কাজ করবে না।
- Android app-এর SHA-1 এবং SHA-256 fingerprints Firebase Project Settings-এ যোগ করতে হবে; বিশেষ করে Phone Auth-এর reCAPTCHA / Play Integrity verification-এর জন্য।
- Firebase SMS quota/region policy প্রযোজ্য হবে। SMS quota শেষ হলে OTP পাঠানো ব্যর্থ হতে পারে।

গুরুত্বপূর্ণ ডেটা সুরক্ষা
- একই নম্বরের একই Firebase account ব্যবহার করুন। অন্য নম্বর দিয়ে নতুন Firebase user তৈরি হলে সেটি আলাদা UID/account হবে; ডেটা নিজে থেকে merge হবে না।
- নম্বর পরিবর্তনের আগে পুরোনো account-এ লগইন থাকতে হবে। নতুন নম্বর আগে অন্য Firebase account-এ ব্যবহৃত হলে update ব্যর্থ হতে পারে; ডেটা মুছে ফেলবেন না বা নতুন account-এ লগইন করে পুরোনো account বদলাবেন না।
- Firestore-এ পুরোনো snapshot স্বয়ংক্রিয়ভাবে delete করা হয় না; ফলে storage বাড়তে পারে।
- Offline-এ আগে থেকে লগইন থাকা ডিভাইসে local data ব্যবহার করা যায়; প্রথমবার OTP login-এর জন্য internet ও SMS দরকার।

Build নির্দেশ
- Android Studio-তে NewMaDurgaAndroid ফোল্ডার খুলুন।
- Gradle Sync করে Build > Build APK(s) চালান।
- এই পরিবেশে Android SDK/Gradle toolchain না থাকায় এখানে APK build বা বাস্তব ফোনে OTP/SMS/Firestore পরীক্ষা করা যায়নি। এটি source ZIP; সরাসরি install করার APK নয়।
