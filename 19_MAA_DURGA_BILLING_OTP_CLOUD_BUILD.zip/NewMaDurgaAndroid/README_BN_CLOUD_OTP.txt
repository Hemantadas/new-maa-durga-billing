নিউ মা দূর্গা বিলিং — OTP Login ও Cloud Sync Source Update

এই Source ZIP-এ যোগ করা হয়েছে:
1) Firebase Phone SMS OTP Login (Android Firebase Auth)
2) OTP যাচাই করে লগইন এবং Firebase user session ধরে রাখা
3) Firestore-এ অ্যাকাউন্ট UID অনুযায়ী ডেটা সংরক্ষণ
4) বিল, পণ্য, কাস্টমার ও সেটিংসের LocalStorage snapshot Sync
5) Offline অবস্থায় স্থানীয় ডেটা রাখা; নেট এলে Cloud Data পড়ে Sync করার চেষ্টা
6) একই ফোন নম্বরের Firebase UID-তে অন্য ফোন লগইন করলে একই অ্যাকাউন্ট ডেটা
7) নতুন নম্বরের OTP যাচাই করে বর্তমান Firebase account-এর phone number update করার ব্যবস্থা
8) আলাদা Firebase UID হলে একই ফোনে আগের দোকানের local data মুছে নতুন UID-এর Cloud Data লোড করা
9) Logout করলে local বা cloud data delete হয় না

গুরুত্বপূর্ণ সীমাবদ্ধতা / পরের ধাপ:
- এই পরিবেশে Android SDK/Gradle নেই; তাই APK build বা বাস্তব Android ফোনে OTP/Firestore পরীক্ষা করা যায়নি।
- Firestore database Firebase Console-এ তৈরি/enable করতে হবে এবং firestore/firestore.rules deploy করতে হবে।
- Firebase Console > Authentication > Sign-in method-এ Phone provider enable থাকতে হবে। SMS quota, test phone এবং App SHA fingerprints ঠিক থাকতে হবে।
- Cloud Sync-এ JSON snapshot ছোট ছোট অংশে `accounts/{uid}/snapshots/{generation}/parts/`-এ রাখা হয়; account document-এ সক্রিয় snapshot-এর পরিচয় থাকে। এতে একক 1 MiB document সীমা এড়ানো যায়। প্রতিটি অংশ 150,000 অক্ষরের মধ্যে রাখা হয় এবং এক Sync-এ সর্বোচ্চ 450টি অংশ লেখা হয়। পুরোনো snapshot আপাতত স্বয়ংক্রিয়ভাবে মুছে ফেলা হয় না—Firestore storage ব্যবহারে নজর রাখতে হবে। এটি এখনও বাস্তব ফোনে পরীক্ষা করা হয়নি; বড় ডেটার production readiness নিশ্চিত নয়।
- বর্তমান মূল অ্যাপে customer list আছে, কিন্তু আলাদা customer balance/ledger ও payment transaction screen নেই; bills-এ payment mode সংরক্ষিত হয়। এই আলাদা হিসাবের ফিচার এখনো যোগ করা বাকি।
- একই নতুন ফোন নম্বর যদি আগে অন্য Firebase account-এ নিবন্ধিত থাকে, updatePhoneNumber ব্যর্থ হতে পারে; দুই account-এর ডেটা স্বয়ংক্রিয়ভাবে merge করা হয় না।
- OTP-সহ একই নম্বর দিয়ে manager অন্য ফোনে লগইন করলে একই Firebase UID/ডেটা পাওয়ার কথা; role-based permission আলাদা করা হয়নি—দুজনের access একই।
- Firestore rules account metadata এবং তার nested snapshot/parts—সব ক্ষেত্রেই শুধু সংশ্লিষ্ট UID-কে read/write দেয়।

Build prerequisites:
- Android Studio
- Android SDK Platform 35
- Gradle compatible with Android Gradle Plugin 8.6.1
- Google Services plugin 4.4.2

Build:
1. NewMaDurgaAndroid folder Android Studio-তে খুলুন
2. Gradle Sync করুন
3. Build > Build APK(s)

Firebase configuration:
- app/google-services.json বর্তমান ZIP-এ থাকা ফাইলটি এই Android package-এর জন্য।
- Firebase Console-এ Firestore Database তৈরি করুন।
- Firebase CLI দিয়ে project root থেকে: firebase deploy --only firestore:rules
