package com.newmadurga.billing;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.widget.Toast;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import com.google.firebase.firestore.FieldValue;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private static final int REQ_BT=701, REQ_CAMERA=702, REQ_FILE=703;
    private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private WebView web;
    private BluetoothAdapter adapter;
    private BluetoothSocket socket;
    private Thread connectThread;
    private final Object lock=new Object();
    private SharedPreferences prefs;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest cameraRequest;
    private FirebaseAuth firebaseAuth;
    private FirebaseAuth.AuthStateListener authStateListener;
    private FirebaseFirestore firestore;
    private String phoneVerificationId = "";
    private String newPhoneVerificationId = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs=getSharedPreferences("printer",MODE_PRIVATE);
        try {
            FirebaseApp.initializeApp(this);
            firebaseAuth=FirebaseAuth.getInstance();
            firestore=FirebaseFirestore.getInstance();
            // Firebase restores the signed-in phone session asynchronously. Listen for the
            // completed restore so a returning user is not incorrectly left at the login gate.
            authStateListener = auth -> notifyAuthState();
            firebaseAuth.addAuthStateListener(authStateListener);
        } catch(Exception e) { android.util.Log.e("MaaDurgaFirebase","Firebase init failed",e); }
        adapter=BluetoothAdapter.getDefaultAdapter();
        web=new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent pick=new Intent(Intent.ACTION_GET_CONTENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("image/*");
                try { startActivityForResult(Intent.createChooser(pick,"ছবি নির্বাচন করুন"),REQ_FILE); }
                catch(Exception e) { fileCallback=null; callback.onReceiveValue(null); toast("Gallery খোলা যাচ্ছে না"); }
                return true;
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                boolean wantsCamera=false;
                for(String r:request.getResources()) if(PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) wantsCamera=true;
                if(!wantsCamera){ request.deny(); return; }
                runOnUiThread(() -> {
                    if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) {
                        cameraRequest=request;
                        requestPermissions(new String[]{Manifest.permission.CAMERA},REQ_CAMERA);
                    } else request.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                });
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view,String url) {
                super.onPageFinished(view,url);
                if(firebaseAuth!=null) notifyAuthState();
            }
        });
        web.addJavascriptInterface(new AccountBridge(),"AndroidAccount");
        web.addJavascriptInterface(new PrinterBridge(),"AndroidPrinter");
        web.addJavascriptInterface(new NativeFilesBridge(),"AndroidFiles");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        requestBluetoothPermissionAndReconnect();
    }

    @Override protected void onDestroy() {
        if(firebaseAuth!=null && authStateListener!=null) firebaseAuth.removeAuthStateListener(authStateListener);
        if(web!=null) web.destroy();
        super.onDestroy();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_FILE && fileCallback!=null) {
            Uri[] result=null;
            if(resultCode==RESULT_OK && data!=null) {
                Uri u=data.getData();
                if(u!=null) result=new Uri[]{u};
            }
            fileCallback.onReceiveValue(result);
            fileCallback=null;
        }
    }

    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==REQ_BT) {
            if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) autoReconnect();
            else toast("Bluetooth অনুমতি দিন");
        } else if(code==REQ_CAMERA) {
            if(cameraRequest!=null) {
                if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED)
                    cameraRequest.grant(new String[]{PermissionRequest.RESOURCE_VIDEO_CAPTURE});
                else cameraRequest.deny();
                cameraRequest=null;
            }
        }
    }

    private void requestBluetoothPermissionAndReconnect() {
        if(adapter==null){toast("এই ফোনে Bluetooth নেই");return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
        else autoReconnect();
    }
    private void autoReconnect() {
        try {
            if(adapter==null || !adapter.isEnabled()){toast("Bluetooth চালু করুন");return;}
            String mac=prefs.getString("mac","");
            if(!mac.isEmpty()) connect(mac,false);
        } catch(SecurityException e){toast("Bluetooth অনুমতি দিন");}
    }
    private void connect(String mac,boolean save) {
        if(adapter==null)return;
        if(connectThread!=null)connectThread.interrupt();
        connectThread=new Thread(() -> {
            BluetoothSocket s=null;
            try {
                BluetoothDevice d=adapter.getRemoteDevice(mac);
                try { s=d.createRfcommSocketToServiceRecord(SPP); s.connect(); }
                catch(Exception secureError) {
                    try { if(s!=null)s.close(); } catch(Exception ignored){}
                    s=d.createInsecureRfcommSocketToServiceRecord(SPP);
                    s.connect();
                }
                synchronized(lock){if(socket!=null)try{socket.close();}catch(Exception ignored){} socket=s;}
                if(save)prefs.edit().putString("mac",mac).apply();
                toast("Bluetooth Printer Connected: "+d.getName());
            } catch(Exception e) {
                if(s!=null)try{s.close();}catch(Exception ignored){}
                toast("Bluetooth কানেক্ট হয়নি। প্রিন্টার Pair করে আবার Connect করুন।");
            }
        });
        connectThread.start();
    }
    private void choosePrinter() {
        if(adapter==null){toast("এই ফোনে Bluetooth নেই");return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionAndReconnect(); return;
        }
        try {
            Set<BluetoothDevice> paired=adapter.getBondedDevices();
            ArrayList<BluetoothDevice> list=new ArrayList<>();
            for(BluetoothDevice d:paired)list.add(d);
            if(list.isEmpty()){toast("আগে ফোনের Bluetooth Settings থেকে ATPOS M80 Pair করুন");return;}
            String[] names=new String[list.size()];
            for(int i=0;i<list.size();i++)names[i]=(list.get(i).getName()==null?"Bluetooth Printer":list.get(i).getName())+"\n"+list.get(i).getAddress();
            new AlertDialog.Builder(this).setTitle("ATPOS M80 নির্বাচন করুন")
                .setItems(names,(dialog,which)->connect(list.get(which).getAddress(),true))
                .setNegativeButton("বাতিল",null).show();
        } catch(SecurityException e){toast("Bluetooth অনুমতি দিন");}
    }


    private void js(String script) {
        runOnUiThread(() -> { if(web!=null) web.evaluateJavascript(script,null); });
    }
    private void notifyAuthState() {
        FirebaseUser u=firebaseAuth==null?null:firebaseAuth.getCurrentUser();
        String uid=u==null?"":u.getUid();
        String phone=u==null?"":(u.getPhoneNumber()==null?"":u.getPhoneNumber());
        js("window.onNativeAuthState && window.onNativeAuthState("+org.json.JSONObject.quote(uid)+","+org.json.JSONObject.quote(phone)+")");
    }
    private class AccountBridge {
        @JavascriptInterface public void sendOtp(String phone) {
            if(firebaseAuth==null){js("window.onOtpError && window.onOtpError('Firebase চালু হয়নি। google-services.json পরীক্ষা করুন।')");return;}
            PhoneAuthOptions options=PhoneAuthOptions.newBuilder(firebaseAuth)
                .setPhoneNumber(phone).setTimeout(60L,TimeUnit.SECONDS).setActivity(MainActivity.this)
                .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
                    @Override public void onVerificationCompleted(PhoneAuthCredential credential){
                        firebaseAuth.signInWithCredential(credential).addOnCompleteListener(task->{
                            if(task.isSuccessful()){notifyAuthState();js("window.onOtpVerified && window.onOtpVerified()");}
                            else js("window.onOtpError && window.onOtpError("+org.json.JSONObject.quote(task.getException()==null?"Login ব্যর্থ":task.getException().getMessage())+")");
                        });
                    }
                    @Override public void onVerificationFailed(com.google.firebase.FirebaseException e){
                        js("window.onOtpError && window.onOtpError("+org.json.JSONObject.quote(e.getMessage()==null?"OTP পাঠানো যায়নি":e.getMessage())+")");
                    }
                    @Override public void onCodeSent(String id,PhoneAuthProvider.ForceResendingToken token){
                        phoneVerificationId=id;js("window.onOtpSent && window.onOtpSent()");
                    }
                }).build();
            PhoneAuthProvider.verifyPhoneNumber(options);
        }
        @JavascriptInterface public void verifyOtp(String code) {
            if(firebaseAuth==null||phoneVerificationId.isEmpty()){js("window.onOtpError && window.onOtpError('আগে OTP পাঠান')");return;}
            PhoneAuthCredential credential=PhoneAuthProvider.getCredential(phoneVerificationId,code);
            firebaseAuth.signInWithCredential(credential).addOnCompleteListener(task->{
                if(task.isSuccessful()){phoneVerificationId="";notifyAuthState();js("window.onOtpVerified && window.onOtpVerified()");}
                else js("window.onOtpError && window.onOtpError("+org.json.JSONObject.quote(task.getException()==null?"OTP ভুল বা মেয়াদ শেষ":task.getException().getMessage())+")");
            });
        }
        @JavascriptInterface public void signOut(){if(firebaseAuth!=null){firebaseAuth.signOut();notifyAuthState();}}
        @JavascriptInterface public void sendChangePhoneOtp(String phone) {
            FirebaseUser user=firebaseAuth==null?null:firebaseAuth.getCurrentUser();
            if(user==null){js("window.onOtpError && window.onOtpError('আগে লগইন করুন')");return;}
            PhoneAuthOptions options=PhoneAuthOptions.newBuilder(firebaseAuth).setPhoneNumber(phone)
                .setTimeout(60L,TimeUnit.SECONDS).setActivity(MainActivity.this)
                .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
                    @Override public void onVerificationCompleted(PhoneAuthCredential credential){applyNewPhone(credential);}
                    @Override public void onVerificationFailed(com.google.firebase.FirebaseException e){js("window.onOtpError && window.onOtpError("+org.json.JSONObject.quote(e.getMessage()==null?"OTP পাঠানো যায়নি":e.getMessage())+")");}
                    @Override public void onCodeSent(String id,PhoneAuthProvider.ForceResendingToken token){newPhoneVerificationId=id;js("window.onChangePhoneOtpSent && window.onChangePhoneOtpSent()");}
                }).build();
            PhoneAuthProvider.verifyPhoneNumber(options);
        }
        @JavascriptInterface public void verifyChangePhoneOtp(String code) {
            if(newPhoneVerificationId.isEmpty()){js("window.onOtpError && window.onOtpError('আগে নতুন নম্বরে OTP পাঠান')");return;}
            applyNewPhone(PhoneAuthProvider.getCredential(newPhoneVerificationId,code));
        }
        private void applyNewPhone(PhoneAuthCredential credential) {
            FirebaseUser user=firebaseAuth==null?null:firebaseAuth.getCurrentUser();
            if(user==null)return;
            user.updatePhoneNumber(credential).addOnCompleteListener(task->{
                if(task.isSuccessful()){newPhoneVerificationId="";notifyAuthState();js("window.onPhoneChanged && window.onPhoneChanged()");}
                else js("window.onOtpError && window.onOtpError("+org.json.JSONObject.quote(task.getException()==null?"নম্বর পরিবর্তন হয়নি":task.getException().getMessage())+")");
            });
        }
        @JavascriptInterface public void syncCloud(String payload) {
            FirebaseUser u=firebaseAuth==null?null:firebaseAuth.getCurrentUser();
            if(u==null||firestore==null){js("window.onCloudError && window.onCloudError('লগইন নেই')");return;}
            if(payload==null)payload="{}";
            final String uid=u.getUid();
            final String generation=UUID.randomUUID().toString();
            // Keep every Firestore document comfortably below the 1 MiB document limit.
            final int partSize=150000;
            final int count=Math.max(1,(payload.length()+partSize-1)/partSize);
            if(count>450){js("window.onCloudError && window.onCloudError('ডেটা অনেক বড়। নিরাপদে Sync করা যায়নি; ডেটা ফোনে আছে।')");return;}
            com.google.firebase.firestore.WriteBatch batch=firestore.batch();
            com.google.firebase.firestore.CollectionReference parts=firestore.collection("accounts").document(uid)
                .collection("snapshots").document(generation).collection("parts");
            for(int i=0;i<count;i++){
                int start=i*partSize, end=Math.min(payload.length(),start+partSize);
                Map<String,Object> part=new HashMap<>();part.put("index",i);part.put("data",payload.substring(start,end));
                batch.set(parts.document(String.format(java.util.Locale.US,"%05d",i)),part);
            }
            final int totalParts=count;
            batch.commit().addOnSuccessListener(v->{
                Map<String,Object> meta=new HashMap<>();meta.put("activeSnapshot",generation);
                meta.put("partCount",totalParts);meta.put("updatedAt",FieldValue.serverTimestamp());
                firestore.collection("accounts").document(uid).set(meta,SetOptions.merge())
                    .addOnSuccessListener(done->js("window.onCloudSaved && window.onCloudSaved()"))
                    .addOnFailureListener(e->js("window.onCloudError && window.onCloudError("+org.json.JSONObject.quote(e.getMessage()==null?"Cloud Sync-এর সূচি সংরক্ষণ হয়নি":e.getMessage())+")"));
            }).addOnFailureListener(e->js("window.onCloudError && window.onCloudError("+org.json.JSONObject.quote(e.getMessage()==null?"Cloud Sync ব্যর্থ":e.getMessage())+")"));
        }
        @JavascriptInterface public void loadCloud() {
            FirebaseUser u=firebaseAuth==null?null:firebaseAuth.getCurrentUser();
            if(u==null||firestore==null){js("window.onCloudError && window.onCloudError('লগইন নেই')");return;}
            final String uid=u.getUid();
            final com.google.firebase.firestore.DocumentReference account=firestore.collection("accounts").document(uid);
            account.get().addOnSuccessListener(doc->{
                if(!doc.exists()){js("window.onCloudLoaded && window.onCloudLoaded(null)");return;}
                // Backward compatibility: read the earlier single-document snapshot if present.
                String legacy=doc.getString("payload");
                if(legacy!=null){js("window.onCloudLoaded && window.onCloudLoaded("+org.json.JSONObject.quote(legacy)+")");return;}
                String generation=doc.getString("activeSnapshot");
                if(generation==null||generation.isEmpty()){js("window.onCloudLoaded && window.onCloudLoaded(null)");return;}
                account.collection("snapshots").document(generation).collection("parts").orderBy("index").get()
                    .addOnSuccessListener(parts->{
                        StringBuilder payload=new StringBuilder();
                        for(com.google.firebase.firestore.QueryDocumentSnapshot part:parts){String value=part.getString("data");if(value!=null)payload.append(value);}
                        js("window.onCloudLoaded && window.onCloudLoaded("+org.json.JSONObject.quote(payload.toString())+")");
                    }).addOnFailureListener(e->js("window.onCloudError && window.onCloudError("+org.json.JSONObject.quote(e.getMessage()==null?"Cloud Data পড়া যায়নি":e.getMessage())+")"));
            }).addOnFailureListener(e->js("window.onCloudError && window.onCloudError("+org.json.JSONObject.quote(e.getMessage()==null?"Cloud Data পড়া যায়নি":e.getMessage())+")"));
        }
        @JavascriptInterface public String currentUid(){FirebaseUser u=firebaseAuth==null?null:firebaseAuth.getCurrentUser();return u==null?"":u.getUid();}
    }

    private class PrinterBridge {
        @JavascriptInterface public void connectPrinter(){runOnUiThread(()->choosePrinter());}
        @JavascriptInterface public boolean isConnected(){synchronized(lock){return socket!=null&&socket.isConnected();}}
        @JavascriptInterface public void printImage(String dataUrl) {
            new Thread(() -> {
                Bitmap source=null,bmp=null;
                try {
                    int comma=dataUrl.indexOf(',');
                    byte[] raw=Base64.decode(comma>=0?dataUrl.substring(comma+1):dataUrl,Base64.DEFAULT);
                    source=BitmapFactory.decodeByteArray(raw,0,raw.length);
                    if(source==null)throw new Exception("Invalid image");
                    int width=576,height=Math.max(1,(int)Math.round(source.getHeight()*(width/(double)source.getWidth())));
                    bmp=Bitmap.createScaledBitmap(source,width,height,true);
                    int row=(width+7)/8; byte[] raster=new byte[row*height];
                    for(int y=0;y<height;y++)for(int x=0;x<width;x++){
                        int c=bmp.getPixel(x,y);
                        int gray=(android.graphics.Color.red(c)*299+android.graphics.Color.green(c)*587+android.graphics.Color.blue(c)*114)/1000;
                        if(gray<178)raster[y*row+x/8]|=(byte)(0x80>>(x%8));
                    }
                    OutputStream out;
                    synchronized(lock){if(socket==null||!socket.isConnected())throw new Exception("Printer disconnected");out=socket.getOutputStream();}
                    out.write(new byte[]{0x1b,0x40});
                    out.write(new byte[]{0x1d,0x76,0x30,0x00,(byte)(row&255),(byte)((row>>8)&255),(byte)(height&255),(byte)((height>>8)&255)});
                    out.write(raster);out.write(new byte[]{0x1b,0x64,0x04});out.write(new byte[]{0x1d,0x56,0x00});out.flush();
                    toast("ATPOS M80-এ বিল প্রিন্ট পাঠানো হয়েছে");
                } catch(Exception e){toast("প্রিন্ট হয়নি। Printer Connect করুন।");}
                finally{if(source!=null)source.recycle();if(bmp!=null&&bmp!=source)bmp.recycle();}
            }).start();
        }
    }

    private class NativeFilesBridge {
        @JavascriptInterface public void shareFile(String dataUrl,String mime,String fileName) {
            new Thread(() -> {
                try {
                    int comma=dataUrl.indexOf(',');
                    byte[] bytes=Base64.decode(comma>=0?dataUrl.substring(comma+1):dataUrl,Base64.DEFAULT);
                    String safeName=fileName.replaceAll("[^A-Za-z0-9._-]","_");
                    ContentValues values=new ContentValues();
                    values.put(MediaStore.MediaColumns.DISPLAY_NAME,safeName);
                    values.put(MediaStore.MediaColumns.MIME_TYPE,mime);
                    if(Build.VERSION.SDK_INT>=29)values.put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/New Ma Durga Bills");
                    Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                    if(uri==null)throw new IOException("ফাইল সংরক্ষণ করা যায়নি");
                    OutputStream out=getContentResolver().openOutputStream(uri);
                    if(out==null)throw new IOException("ফাইল লেখা যায়নি");
                    out.write(bytes);out.flush();out.close();
                    runOnUiThread(() -> {
                        Intent send=new Intent(Intent.ACTION_SEND);
                        send.setType(mime);send.putExtra(Intent.EXTRA_STREAM,uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send,"বিল শেয়ার করুন"));
                    });
                } catch(Exception e){toast("বিল তৈরি হয়েছে, কিন্তু Share খোলা যায়নি। Downloads ফোল্ডার দেখুন।");}
            }).start();
        }
    }

    private void toast(String s){runOnUiThread(()->Toast.makeText(this,s,Toast.LENGTH_LONG).show());}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
}
